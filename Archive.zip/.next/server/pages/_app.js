/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/app/store.ts":
/*!**************************!*\
  !*** ./src/app/store.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"store\": () => (/* binding */ store)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _features_auth_authSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../features/auth/authSlice */ \"./src/features/auth/authSlice.ts\");\n\n\nconst store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n  reducer: {\n    auth: _features_auth_authSlice__WEBPACK_IMPORTED_MODULE_1__[\"default\"]\n  }\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvYXBwL3N0b3JlLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUtFO0FBRU8sTUFBTUUsS0FBSyxHQUFHRixnRUFBYyxDQUFDO0FBQ2xDRyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsSUFBSSxFQUFFSCxnRUFBV0E7QUFEVjtBQUR5QixDQUFELENBQTVCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGVzdC10YXNrLy4vc3JjL2FwcC9zdG9yZS50cz8xNDdiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gICAgQWN0aW9uLFxuICAgIGNvbmZpZ3VyZVN0b3JlLFxuICAgIFRodW5rQWN0aW9uLFxuICB9IGZyb20gJ0ByZWR1eGpzL3Rvb2xraXQnO1xuICBpbXBvcnQgYXV0aFJlZHVjZXIgZnJvbSAnLi4vZmVhdHVyZXMvYXV0aC9hdXRoU2xpY2UnO1xuICBcbiAgZXhwb3J0IGNvbnN0IHN0b3JlID0gY29uZmlndXJlU3RvcmUoe1xuICAgIHJlZHVjZXI6IHtcbiAgICAgIGF1dGg6IGF1dGhSZWR1Y2VyLFxuICAgIH0sXG4gIH0pO1xuICBcbiAgZXhwb3J0IHR5cGUgQXBwRGlzcGF0Y2ggPSB0eXBlb2Ygc3RvcmUuZGlzcGF0Y2g7XG4gIGV4cG9ydCB0eXBlIFJvb3RTdGF0ZSA9IFJldHVyblR5cGU8dHlwZW9mIHN0b3JlLmdldFN0YXRlPjtcbiAgZXhwb3J0IHR5cGUgQXBwVGh1bms8UmV0dXJuVHlwZSA9IHZvaWQ+ID0gVGh1bmtBY3Rpb248XG4gICAgUmV0dXJuVHlwZSxcbiAgICBSb290U3RhdGUsXG4gICAgdW5rbm93bixcbiAgICBBY3Rpb248c3RyaW5nPlxuICA+OyJdLCJuYW1lcyI6WyJjb25maWd1cmVTdG9yZSIsImF1dGhSZWR1Y2VyIiwic3RvcmUiLCJyZWR1Y2VyIiwiYXV0aCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/app/store.ts\n");

/***/ }),

/***/ "./src/features/auth/authSlice.ts":
/*!****************************************!*\
  !*** ./src/features/auth/authSlice.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"counterSlice\": () => (/* binding */ counterSlice),\n/* harmony export */   \"submitForm\": () => (/* binding */ submitForm),\n/* harmony export */   \"selectCount\": () => (/* binding */ selectCount),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n\nconst initialState = {\n  signUpFormValues: {\n    type: '',\n    value: ''\n  }\n};\nconst counterSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({\n  name: 'auth',\n  initialState,\n  reducers: {\n    submitForm: (state, action) => {\n      state.signUpFormValues = action.payload;\n    }\n  }\n}); // Here we are just exporting the actions from this slice, so that we can call them anywhere in our app.\n\nconst {\n  submitForm\n} = counterSlice.actions;\nconst selectCount = state => state.auth.signUpFormValues; // exporting the reducer here, as we need to add this to the store\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (counterSlice.reducer);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvZmVhdHVyZXMvYXV0aC9hdXRoU2xpY2UudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFhRSxNQUFNQyxZQUEwQixHQUFHO0FBQ2pDQyxFQUFBQSxnQkFBZ0IsRUFBRTtBQUNoQkMsSUFBQUEsSUFBSSxFQUFFLEVBRFU7QUFFaEJDLElBQUFBLEtBQUssRUFBRTtBQUZTO0FBRGUsQ0FBbkM7QUFPTyxNQUFNQyxZQUFZLEdBQUdMLDZEQUFXLENBQUM7QUFDdENNLEVBQUFBLElBQUksRUFBRSxNQURnQztBQUV0Q0wsRUFBQUEsWUFGc0M7QUFHdENNLEVBQUFBLFFBQVEsRUFBRTtBQUNSQyxJQUFBQSxVQUFVLEVBQUUsQ0FBQ0MsS0FBRCxFQUFRQyxNQUFSLEtBQW1CO0FBQzdCRCxNQUFBQSxLQUFLLENBQUNQLGdCQUFOLEdBQXlCUSxNQUFNLENBQUNDLE9BQWhDO0FBQ0Q7QUFITztBQUg0QixDQUFELENBQWhDLEVBV1A7O0FBQ08sTUFBTTtBQUNYSCxFQUFBQTtBQURXLElBRVRILFlBQVksQ0FBQ08sT0FGVjtBQUtBLE1BQU1DLFdBQVcsR0FBSUosS0FBRCxJQUFzQkEsS0FBSyxDQUFDSyxJQUFOLENBQVdaLGdCQUFyRCxFQUVQOztBQUNBLGlFQUFlRyxZQUFZLENBQUNVLE9BQTVCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGVzdC10YXNrLy4vc3JjL2ZlYXR1cmVzL2F1dGgvYXV0aFNsaWNlLnRzP2NmOGQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgICBjcmVhdGVTbGljZSxcbiAgfSBmcm9tICdAcmVkdXhqcy90b29sa2l0JztcbiAgaW1wb3J0IHR5cGUgeyBSb290U3RhdGUgfSBmcm9tICcuLi8uLi9hcHAvc3RvcmUnO1xuICBcbiAgLy8gZGVjbGFyaW5nIHRoZSB0eXBlcyBmb3Igb3VyIHN0YXRlXG4gIGV4cG9ydCB0eXBlIENvdW50ZXJTdGF0ZSA9IHtcbiAgICBzaWduVXBGb3JtVmFsdWVzOiB7XG4gICAgICB0eXBlOiAnJyxcbiAgICAgIHZhbHVlOiAnJ1xuICAgIH1cbiAgfTtcbiAgXG4gIGNvbnN0IGluaXRpYWxTdGF0ZTogQ291bnRlclN0YXRlID0ge1xuICAgIHNpZ25VcEZvcm1WYWx1ZXM6IHtcbiAgICAgIHR5cGU6ICcnLFxuICAgICAgdmFsdWU6ICcnXG4gICAgfVxuICB9O1xuICBcbiAgZXhwb3J0IGNvbnN0IGNvdW50ZXJTbGljZSA9IGNyZWF0ZVNsaWNlKHtcbiAgICBuYW1lOiAnYXV0aCcsXG4gICAgaW5pdGlhbFN0YXRlLFxuICAgIHJlZHVjZXJzOiB7XG4gICAgICBzdWJtaXRGb3JtOiAoc3RhdGUsIGFjdGlvbikgPT4ge1xuICAgICAgICBzdGF0ZS5zaWduVXBGb3JtVmFsdWVzID0gYWN0aW9uLnBheWxvYWRcbiAgICAgIH0sXG4gICAgICBcbiAgICAgIFxuICAgIH0sXG4gIH0pO1xuICAvLyBIZXJlIHdlIGFyZSBqdXN0IGV4cG9ydGluZyB0aGUgYWN0aW9ucyBmcm9tIHRoaXMgc2xpY2UsIHNvIHRoYXQgd2UgY2FuIGNhbGwgdGhlbSBhbnl3aGVyZSBpbiBvdXIgYXBwLlxuICBleHBvcnQgY29uc3Qge1xuICAgIHN1Ym1pdEZvcm0sXG4gIH0gPSBjb3VudGVyU2xpY2UuYWN0aW9ucztcbiAgXG4gIFxuICBleHBvcnQgY29uc3Qgc2VsZWN0Q291bnQgPSAoc3RhdGU6IFJvb3RTdGF0ZSkgPT4gc3RhdGUuYXV0aC5zaWduVXBGb3JtVmFsdWVzO1xuICBcbiAgLy8gZXhwb3J0aW5nIHRoZSByZWR1Y2VyIGhlcmUsIGFzIHdlIG5lZWQgdG8gYWRkIHRoaXMgdG8gdGhlIHN0b3JlXG4gIGV4cG9ydCBkZWZhdWx0IGNvdW50ZXJTbGljZS5yZWR1Y2VyOyJdLCJuYW1lcyI6WyJjcmVhdGVTbGljZSIsImluaXRpYWxTdGF0ZSIsInNpZ25VcEZvcm1WYWx1ZXMiLCJ0eXBlIiwidmFsdWUiLCJjb3VudGVyU2xpY2UiLCJuYW1lIiwicmVkdWNlcnMiLCJzdWJtaXRGb3JtIiwic3RhdGUiLCJhY3Rpb24iLCJwYXlsb2FkIiwiYWN0aW9ucyIsInNlbGVjdENvdW50IiwiYXV0aCIsInJlZHVjZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/features/auth/authSlice.ts\n");

/***/ }),

/***/ "./src/pages/_app.tsx":
/*!****************************!*\
  !*** ./src/pages/_app.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-redux */ \"react-redux\");\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _app_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../app/store */ \"./src/app/store.ts\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/react/jsx-dev-runtime */ \"@emotion/react/jsx-dev-runtime\");\n/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);\nvar _jsxFileName = \"/Users/mudasserhussian/Downloads/projects/Nextjs test task/test-task/src/pages/_app.tsx\";\n\nfunction ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }\n\nfunction _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }\n\nfunction _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }\n\n\n\n\n\n\nfunction MyApp({\n  Component,\n  pageProps\n}) {\n  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_redux__WEBPACK_IMPORTED_MODULE_0__.Provider, {\n    store: _app_store__WEBPACK_IMPORTED_MODULE_1__.store,\n    children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Component, _objectSpread({}, pageProps), void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 12,\n      columnNumber: 7\n    }, this)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 11,\n    columnNumber: 5\n  }, this);\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRUE7QUFFQTs7O0FBRUEsU0FBU0UsS0FBVCxDQUFlO0FBQ2JDLEVBQUFBLFNBRGE7QUFDRkMsRUFBQUE7QUFERSxDQUFmLEVBRWE7QUFDWCxTQUNFLHVFQUFDLGlEQUFEO0FBQVUsU0FBSyxFQUFFSCw2Q0FBakI7QUFBQSxjQUNFLHVFQUFDLFNBQUQsb0JBQWVHLFNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQUtEOztBQUVELGlFQUFlRixLQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGVzdC10YXNrLy4vc3JjL3BhZ2VzL19hcHAudHN4P2Y5ZDYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUHJvdmlkZXIgfSBmcm9tICdyZWFjdC1yZWR1eCc7XG5pbXBvcnQgdHlwZSB7IEFwcFByb3BzIH0gZnJvbSAnbmV4dC9hcHAnO1xuaW1wb3J0IHsgc3RvcmUgfSBmcm9tICcuLi9hcHAvc3RvcmUnO1xuXG5pbXBvcnQgJy4uLy4uL3N0eWxlcy9nbG9iYWxzLmNzcydcblxuZnVuY3Rpb24gTXlBcHAoe1xuICBDb21wb25lbnQsIHBhZ2VQcm9wcyxcbn06IEFwcFByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPFByb3ZpZGVyIHN0b3JlPXtzdG9yZX0+XG4gICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgPC9Qcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgTXlBcHA7Il0sIm5hbWVzIjpbIlByb3ZpZGVyIiwic3RvcmUiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/pages/_app.tsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@emotion/react/jsx-dev-runtime":
/*!*************************************************!*\
  !*** external "@emotion/react/jsx-dev-runtime" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/react/jsx-dev-runtime");

/***/ }),

/***/ "@reduxjs/toolkit":
/*!***********************************!*\
  !*** external "@reduxjs/toolkit" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.tsx"));
module.exports = __webpack_exports__;

})();